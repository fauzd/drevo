This font is distributed under a Creative Commons license.
The only condition for the free use of the font is the attribution in the form: Novelist developed by Alena Krachkovskaya at HSE ART AND DESIGN SCHOOL

Этот шрифт распространяется по лицензии Creative Commons.
Единственное условие бесплатного использования шрифта — это указание авторства в виде: Новелист разработан Аленой Крачковской в Школе дизайна НИУ ВШЭ 

https://hsedesignlab.ru/hsefonts

